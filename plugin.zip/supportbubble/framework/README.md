# framework
```
  require_once 'framework/framework.php';

  $framework = new PluginCube\Framework([
      'id' => '6915',
      'slug' => 'support-bubble',
      'title' => 'support-bubble',
      'icon' => 'data:image/svg+xml;base64,' . base64_encode(file_get_contents('assets/images/logo-menu.svg')),
  ]);
```
